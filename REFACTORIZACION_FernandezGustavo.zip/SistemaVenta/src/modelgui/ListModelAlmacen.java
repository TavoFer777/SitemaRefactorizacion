package modelgui;

import controllers.CAlmacen;
import modelbd.Almacen;
import java.util.ArrayList;
import javax.swing.DefaultListModel;

/**
 *
 * @author Ferz
 */
public class ListModelAlmacen extends DefaultListModel{

    private final CAlmacen ca;
    public ListModelAlmacen(boolean todos) {
        ca = new CAlmacen();
        ArrayList<Almacen> almacenes = ca.getRegistros(todos?new Integer[]{1}:null);
        
        almacenes.forEach((al) -> {
            this.addElement(al);
        });
    }
}
